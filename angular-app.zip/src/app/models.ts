export interface Building {
  name: string;
  use: string;
  period: string;
  renovated: 'Yes' | 'No';
  gfa: number;
  zone: string;
  diversity: number;
  epc: string;
}

export interface Variant {
  name: string;
  techs: string[];
}

export type Carrier = 'Heat' | 'Elec' | 'DHW' | 'Cool';

export interface CarrierPeaks {
  Heat: number;
  Elec: number;
  DHW: number;
  Cool: number;
}

export interface TechEntry {
  name: string;
  sub: string;
  icon: string;
}
