import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Building, Variant } from './models';
import { DEFAULT_BUILDINGS, DEFAULT_VARIANTS, STEP_DEFS } from './data';
import { StepSiteComponent } from './step-site/step-site.component';
import { StepVariantsComponent } from './step-variants/step-variants.component';
import { StepSummaryComponent } from './step-summary/step-summary.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, StepSiteComponent, StepVariantsComponent, StepSummaryComponent],
  templateUrl: './app.component.html',
})
export class AppComponent {
  readonly STEP_DEFS = STEP_DEFS;

  buildings: Building[] = DEFAULT_BUILDINGS.map((b) => ({ ...b }));
  variants: Variant[] = DEFAULT_VARIANTS.map((v) => ({ name: v.name, techs: [...v.techs] }));

  currentStep = 0;

  submitting = false;
  submitDone = false;
  submitLog: string[] = [];

  goTo(index: number): void {
    this.currentStep = Math.max(0, Math.min(this.STEP_DEFS.length - 1, index));
  }

  next(): void {
    this.goTo(this.currentStep + 1);
  }

  back(): void {
    this.goTo(this.currentStep - 1);
  }

  get isLastStep(): boolean {
    return this.currentStep === this.STEP_DEFS.length - 1;
  }

  async submit(): Promise<void> {
    this.submitting = true;
    this.submitDone = false;
    this.submitLog = [];
    this.submitLog.push('Write backend API calls / solver invocation here.');
    this.submitLog.push(`Solving ${this.variants.length} variant(s) over ${this.buildings.length} building type(s)…`);
    for (const v of this.variants) {
      await this.sleep(300);
      this.submitLog.push(`  • ${v.name}: ${v.techs.join(', ') || '—'}`);
    }
    await this.sleep(200);
    this.submitLog.push('✓ Done!');
    this.submitting = false;
    this.submitDone = true;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
