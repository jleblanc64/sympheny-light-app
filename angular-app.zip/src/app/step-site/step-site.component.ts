import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Building, CarrierPeaks } from '../models';
import { CARRIERS, CLIMATE_ZONES, EPC_CLASSES, EPC_COLOR, PERIODS, USE_TYPES } from '../data';
import { CalcService } from '../calc.service';
import { BarChartComponent } from '../bar-chart/bar-chart.component';

@Component({
  selector: 'app-step-site',
  standalone: true,
  imports: [CommonModule, FormsModule, BarChartComponent],
  templateUrl: './step-site.component.html',
})
export class StepSiteComponent {
  @Input({ required: true }) buildings!: Building[];

  readonly USE_TYPES = USE_TYPES;
  readonly PERIODS = PERIODS;
  readonly CLIMATE_ZONES = CLIMATE_ZONES;
  readonly EPC_CLASSES = EPC_CLASSES;
  readonly EPC_COLOR = EPC_COLOR;
  readonly CARRIERS = CARRIERS;

  selected = 0;

  constructor(public calc: CalcService) {}

  get current(): Building | undefined {
    return this.buildings[this.selected];
  }

  pick(i: number): void {
    if (i >= 0 && i < this.buildings.length) this.selected = i;
  }

  addBuilding(): void {
    this.buildings.push({
      name: `Building type ${this.buildings.length + 1}`,
      use: 'Office',
      period: '2000–2010',
      renovated: 'No',
      gfa: 1000.0,
      zone: CLIMATE_ZONES[0],
      diversity: 10.0,
      epc: 'C',
    });
    this.selected = this.buildings.length - 1;
  }

  removeBuilding(): void {
    if (this.buildings.length <= 1) return;
    this.buildings.splice(this.selected, 1);
    this.selected = Math.max(0, this.selected - 1);
  }

  setEpc(cls: string): void {
    if (this.current) this.current.epc = cls;
  }

  peaksFor(b: Building): CarrierPeaks {
    return this.calc.peaks(b);
  }

  hasCool(b: Building): boolean {
    return this.peaksFor(b).Cool > 0;
  }

  get totals() {
    return this.calc.totals(this.buildings);
  }
}
