import { Injectable } from '@angular/core';
import { Building, Carrier, CarrierPeaks } from './models';
import { CARRIERS, EPC_HEAT_W_M2, FULL_LOAD_HOURS, USE_PROFILE } from './data';

@Injectable({ providedIn: 'root' })
export class CalcService {
  /** Peak power per carrier [kW] for one building type. */
  peaks(b: Building): CarrierPeaks {
    const gfa = Number(b.gfa) || 0;
    const prof = USE_PROFILE[b.use] ?? USE_PROFILE['Office'];
    return {
      Heat: (gfa * EPC_HEAT_W_M2[b.epc]) / 1000.0,
      Elec: (gfa * prof.Elec) / 1000.0,
      DHW: (gfa * prof.DHW) / 1000.0,
      Cool: (gfa * prof.Cool) / 1000.0,
    };
  }

  /** Annual energy [MWh/y] from a peak [kW]. */
  annual(carrier: Carrier, peakKw: number): number {
    return (peakKw * FULL_LOAD_HOURS[carrier]) / 1000.0;
  }

  /** Normalised 24h daily-average shape for a carrier. */
  shape(carrier: Carrier): number[] {
    const v: number[] = [];
    for (let h = 0; h < 24; h++) {
      let val: number;
      if (carrier === 'Heat') {
        val = 0.45 + 0.55 * Math.exp(-((h - 7) ** 2) / 7.0) + 0.4 * Math.exp(-((h - 19) ** 2) / 9.0);
      } else if (carrier === 'Elec') {
        val = 0.3 + 0.45 * Math.exp(-((h - 11) ** 2) / 14.0) + 0.6 * Math.exp(-((h - 19) ** 2) / 6.0);
      } else if (carrier === 'DHW') {
        val = 0.15 + 0.85 * Math.exp(-((h - 7) ** 2) / 3.0) + 0.7 * Math.exp(-((h - 20) ** 2) / 4.0);
      } else {
        val = 0.05 + 0.95 * Math.exp(-((h - 15) ** 2) / 9.0);
      }
      v.push(val);
    }
    const top = Math.max(...v);
    return v.map((x) => x / top);
  }

  private shapeCache = new Map<Carrier, number[]>();
  shapeCached(carrier: Carrier): number[] {
    if (!this.shapeCache.has(carrier)) this.shapeCache.set(carrier, this.shape(carrier));
    return this.shapeCache.get(carrier)!;
  }

  emptyPeaks(): CarrierPeaks {
    return { Heat: 0, Elec: 0, DHW: 0, Cool: 0 };
  }

  /** Aggregate surface, coincident peaks, mean diversity % and coincidence factor across all building types. */
  totals(buildings: Building[]): { surface: number; peaks: CarrierPeaks; diversity: number; coincidence: number } {
    let surface = 0;
    const peaks = this.emptyPeaks();
    for (const b of buildings) {
      surface += Number(b.gfa) || 0;
      const p = this.peaks(b);
      for (const c of CARRIERS) peaks[c.name] += p[c.name];
    }
    const diversity = buildings.length
      ? buildings.reduce((sum, b) => sum + (Number(b.diversity) || 0), 0) / buildings.length
      : 0;
    const coincidence = Math.max(0, 1 - diversity / 100.0);
    const coincidentPeaks = this.emptyPeaks();
    for (const c of CARRIERS) coincidentPeaks[c.name] = peaks[c.name] * coincidence;
    return { surface, peaks: coincidentPeaks, diversity, coincidence };
  }
}
