import { AfterViewInit, Component, ElementRef, Input, OnChanges, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CARRIERS } from '../data';
import { CalcService } from '../calc.service';
import { Carrier, CarrierPeaks } from '../models';

@Component({
  selector: 'app-bar-chart',
  standalone: true,
  template: `
    <div class="chart-wrap" [style.height.px]="height">
      <div class="chart-title" *ngIf="title">{{ title }}</div>
      <canvas #canvas></canvas>
      <div class="chart-legend">
        <span *ngFor="let c of activeCarriers()" class="legend-item">
          <i [style.background]="c.color"></i>{{ c.name }}
        </span>
      </div>
    </div>
  `,
  styles: [
    `
      .chart-wrap { position: relative; width: 100%; display: flex; flex-direction: column; }
      .chart-title { font-size: 11px; color: #1f2933; margin: 0 0 2px 4px; }
      canvas { width: 100%; flex: 1; display: block; }
      .chart-legend { display: flex; gap: 14px; justify-content: flex-end; padding: 0 6px; }
      .legend-item { font-size: 10px; color: #4a5568; display: flex; align-items: center; gap: 4px; }
      .legend-item i { width: 9px; height: 9px; border-radius: 2px; display: inline-block; }
    `,
  ],
  imports: [CommonModule],
})
export class BarChartComponent implements AfterViewInit, OnChanges {
  @Input() peaks: CarrierPeaks = { Heat: 0, Elec: 0, DHW: 0, Cool: 0 };
  @Input() title = '';
  @Input() height = 150;

  @ViewChild('canvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  private ready = false;

  constructor(private calc: CalcService) {}

  ngAfterViewInit(): void {
    this.ready = true;
    this.draw();
    window.addEventListener('resize', () => this.draw());
  }

  ngOnChanges(): void {
    if (this.ready) this.draw();
  }

  activeCarriers() {
    return CARRIERS.filter((c) => (this.peaks[c.name] ?? 0) > 0);
  }

  private draw(): void {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;
    const parent = canvas.parentElement!;
    const dpr = window.devicePixelRatio || 1;
    const cssW = parent.clientWidth;
    const cssH = Math.max(60, this.height - (this.title ? 20 : 0) - 16);
    canvas.width = cssW * dpr;
    canvas.height = cssH * dpr;
    canvas.style.width = cssW + 'px';
    canvas.style.height = cssH + 'px';
    const ctx = canvas.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);

    const active = this.activeCarriers();
    if (!active.length) return;

    const marginLeft = 38;
    const marginRight = 6;
    const marginBottom = 4;
    const marginTop = 4;
    const plotW = cssW - marginLeft - marginRight;
    const plotH = cssH - marginTop - marginBottom;

    let maxVal = 0;
    const series: Record<Carrier, number[]> = { Heat: [], Elec: [], DHW: [], Cool: [] };
    for (const c of active) {
      const shape = this.calc.shapeCached(c.name);
      const vals = shape.map((s) => this.peaks[c.name] * s);
      series[c.name] = vals;
      maxVal = Math.max(maxVal, ...vals);
    }
    if (maxVal <= 0) return;
    maxVal *= 1.08;

    // gridlines + y-axis labels
    ctx.strokeStyle = '#eef1f4';
    ctx.fillStyle = '#8a94a0';
    ctx.font = '9px sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    const ySteps = 3;
    for (let i = 0; i <= ySteps; i++) {
      const val = (maxVal / ySteps) * i;
      const y = marginTop + plotH - (val / maxVal) * plotH;
      ctx.beginPath();
      ctx.moveTo(marginLeft, y);
      ctx.lineTo(marginLeft + plotW, y);
      ctx.stroke();
      ctx.fillText(Math.round(val) + '', marginLeft - 6, y);
    }

    // grouped bars, one group per hour
    const hours = 24;
    const groupW = plotW / hours;
    const barGap = 0.15 * groupW;
    const barW = (groupW - barGap) / active.length;

    active.forEach((c, ci) => {
      ctx.fillStyle = c.color;
      for (let h = 0; h < hours; h++) {
        const val = series[c.name][h];
        const barH = (val / maxVal) * plotH;
        const x = marginLeft + h * groupW + barGap / 2 + ci * barW;
        const y = marginTop + plotH - barH;
        ctx.fillRect(x, y, Math.max(1, barW - 1), barH);
      }
    });
  }
}
