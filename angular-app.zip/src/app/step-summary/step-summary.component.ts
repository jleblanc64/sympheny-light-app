import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Building, Variant } from '../models';
import { EPC_COLOR, VARIANT_COLORS } from '../data';
import { CalcService } from '../calc.service';

@Component({
  selector: 'app-step-summary',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './step-summary.component.html',
})
export class StepSummaryComponent {
  @Input({ required: true }) buildings!: Building[];
  @Input({ required: true }) variants!: Variant[];

  readonly EPC_COLOR = EPC_COLOR;
  readonly VARIANT_COLORS = VARIANT_COLORS;

  constructor(public calc: CalcService) {}

  get totals() {
    return this.calc.totals(this.buildings);
  }

  peaksFor(b: Building) {
    return this.calc.peaks(b);
  }

  hasCool(b: Building): boolean {
    return this.peaksFor(b).Cool > 0;
  }

  color(vi: number): string {
    return VARIANT_COLORS[vi % VARIANT_COLORS.length];
  }
}
