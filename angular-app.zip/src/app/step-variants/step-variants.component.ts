import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Variant } from '../models';
import { TECH_CATALOG, TECH_INDEX, VARIANT_COLORS } from '../data';

@Component({
  selector: 'app-step-variants',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './step-variants.component.html',
})
export class StepVariantsComponent {
  @Input({ required: true }) variants!: Variant[];

  readonly TECH_CATALOG = TECH_CATALOG;
  readonly TECH_INDEX = TECH_INDEX;
  readonly VARIANT_COLORS = VARIANT_COLORS;
  readonly catNames = Object.keys(TECH_CATALOG);

  modalOpen = false;
  modalTargetIndex = 0;

  color(vi: number): string {
    return VARIANT_COLORS[vi % VARIANT_COLORS.length];
  }

  chosenTechs(v: Variant, cat: string) {
    return this.TECH_CATALOG[cat].filter((t) => v.techs.includes(t.name));
  }

  availableTechs(vi: number, cat: string) {
    const v = this.variants[vi];
    return this.TECH_CATALOG[cat].filter((t) => !v.techs.includes(t.name));
  }

  hasAnyAvailable(vi: number): boolean {
    return this.catNames.some((cat) => this.availableTechs(vi, cat).length > 0);
  }

  openModal(vi: number): void {
    this.modalTargetIndex = vi;
    this.modalOpen = true;
  }

  closeModal(): void {
    this.modalOpen = false;
  }

  addTech(tech: string): void {
    const v = this.variants[this.modalTargetIndex];
    if (!v.techs.includes(tech)) v.techs.push(tech);
    this.closeModal();
  }

  removeTech(vi: number, tech: string): void {
    const v = this.variants[vi];
    v.techs = v.techs.filter((t) => t !== tech);
  }

  addVariant(): void {
    this.variants.push({ name: `Variant ${this.variants.length + 1}`, techs: ['Grid import / export'] });
  }

  removeVariant(vi: number): void {
    if (this.variants.length > 1) this.variants.splice(vi, 1);
  }
}
