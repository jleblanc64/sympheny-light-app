import { Building, Carrier, TechEntry, Variant } from './models';

export const STEP_DEFS: [string, string][] = [
  ['1', 'Site & buildings'],
  ['2', 'System variants'],
  ['3', 'Summary'],
];

export const CARRIERS: { name: Carrier; color: string }[] = [
  { name: 'Heat', color: '#e0524d' },
  { name: 'Elec', color: '#1fab8c' },
  { name: 'DHW', color: '#f2a93b' },
  { name: 'Cool', color: '#4472c4' },
];
export const CARRIER_COLOR: Record<Carrier, string> = {
  Heat: '#e0524d',
  Elec: '#1fab8c',
  DHW: '#f2a93b',
  Cool: '#4472c4',
};

export const FULL_LOAD_HOURS: Record<Carrier, number> = { Heat: 1580, Elec: 1640, DHW: 2420, Cool: 800 };

export const USE_TYPES = ['Multi-family house', 'Single-family house', 'Office', 'Retail', 'School', 'Hotel', 'Industrial hall'];

export const USE_PROFILE: Record<string, { Elec: number; DHW: number; Cool: number }> = {
  'Multi-family house': { Elec: 5.5, DHW: 1.6, Cool: 0.0 },
  'Single-family house': { Elec: 5.0, DHW: 1.8, Cool: 0.0 },
  Office: { Elec: 12.0, DHW: 0.4, Cool: 8.0 },
  Retail: { Elec: 18.0, DHW: 0.5, Cool: 12.0 },
  School: { Elec: 8.0, DHW: 0.9, Cool: 4.0 },
  Hotel: { Elec: 10.0, DHW: 3.2, Cool: 6.0 },
  'Industrial hall': { Elec: 14.0, DHW: 0.3, Cool: 3.0 },
};

export const PERIODS = ['< 1950', '1950–1970', '1970–1990', '1990–2000', '2000–2010', '> 2010'];
export const CLIMATE_ZONES = ['Zürich, CH', 'Genève, CH', 'Basel, CH', 'Lugano, CH', 'Lyon, FR', 'Milano, IT', 'München, DE'];
export const EPC_CLASSES = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
export const EPC_HEAT_W_M2: Record<string, number> = { A: 4.0, B: 6.5, C: 9.0, D: 14.6, E: 20.0, F: 26.0, G: 33.0 };
export const EPC_COLOR: Record<string, string> = {
  A: '#2e9e4f', B: '#6cb33f', C: '#b7cf2b', D: '#ef7215', E: '#e8546a', F: '#b45ad0', G: '#8a94a0',
};

export const DEFAULT_BUILDINGS: Building[] = [
  { name: 'Residential MFH', use: 'Multi-family house', period: '1990–2000', renovated: 'No', gfa: 23460.0, zone: 'Zürich, CH', diversity: 8.0, epc: 'D' },
  { name: 'Offices', use: 'Office', period: '2000–2010', renovated: 'Yes', gfa: 4800.0, zone: 'Zürich, CH', diversity: 12.0, epc: 'C' },
  { name: 'Retail', use: 'Retail', period: '1970–1990', renovated: 'No', gfa: 1200.0, zone: 'Zürich, CH', diversity: 15.0, epc: 'E' },
];

export const TECH_CATALOG: Record<string, TechEntry[]> = {
  'Heat supply': [
    { name: 'Gas boiler', sub: 'η 92% · gas import · CH grid tariff', icon: '🔥' },
    { name: 'District heating', sub: 'Import price time-series', icon: '♨️' },
    { name: 'Air-source heat pump', sub: 'COP 3.0 · elec import', icon: '💧' },
    { name: 'Ground-source HP', sub: 'COP 4.5 · borehole', icon: '🌡️' },
    { name: 'Wood pellet boiler', sub: 'η 88% · pellet price CH', icon: '🪵' },
  ],
  'Electricity & renewables': [
    { name: 'Grid import / export', sub: 'CH tariff · auto-sized', icon: '⚡' },
    { name: 'Solar PV', sub: 'Roof area from GIS', icon: '☀️' },
    { name: 'Battery storage', sub: 'Li-ion · auto-sized', icon: '🔋' },
    { name: 'CHP unit', sub: 'Gas engine · heat-led', icon: '⚙️' },
  ],
};

export const TECH_INDEX: Record<string, { cat: string; sub: string; icon: string }> = Object.fromEntries(
  Object.entries(TECH_CATALOG).flatMap(([cat, items]) => items.map((t) => [t.name, { cat, sub: t.sub, icon: t.icon }])),
);

export const VARIANT_COLORS = ['#0f9d8f', '#1a6fc4', '#e0952b', '#9c1a6f', '#5a4fcf'];

export const DEFAULT_VARIANTS: Variant[] = [
  { name: 'Status quo / Gas boiler', techs: ['Gas boiler', 'Grid import / export'] },
  { name: 'Heat pump + Solar PV', techs: ['Air-source heat pump', 'Solar PV', 'Grid import / export'] },
  { name: 'District heating + PV', techs: ['District heating', 'Solar PV', 'Grid import / export'] },
];
