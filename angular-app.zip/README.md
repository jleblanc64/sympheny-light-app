# Energy System Wizard (Angular)

Angular 18 port of the original Voila/ipywidgets 3-step configuration wizard
(site & buildings → system variants → summary). Standalone components,
no NgRx/Material — plain SCSS ported 1:1 from the original `WZ_CSS` tokens.

## Structure

```
src/app/
  data.ts                 constants (use types, EPC classes, tech catalog, defaults)
  models.ts                TypeScript interfaces (Building, Variant, ...)
  calc.service.ts           peaks/annual-energy/hourly-shape math (ported from _peaks/_annual/_shape)
  bar-chart/                canvas-based grouped hourly bar chart (replaces the Plotly figure)
  step-site/                Step 1 — building type list, form, KPIs, chart
  step-variants/            Step 2 — variant columns + "Add technology" modal
  step-summary/             Step 3 — read-only recap
  app.component.*           wizard shell: nav bar, step routing, footer, submit
```

## Local development

```bash
npm install
npm start          # ng serve --host 0.0.0.0 --port 4200
```

Then open http://localhost:4200.

## Production build

```bash
npm run build       # outputs to dist/energy-system-wizard
```

Serve the `dist/energy-system-wizard/browser` folder with any static file
server (nginx, `npx http-server`, etc).

## Notes on the port

- The `_work_submit` backend hook (where the original called into Python /
  a solver) is now `AppComponent.submit()` — replace its body with a real
  HTTP call to your backend/API.
- The Plotly hourly-profile chart was replaced with a small dependency-free
  canvas chart (`app-bar-chart`) that reproduces the same grouped-bar look.
- All fake/default data (`DEFAULT_BUILDINGS`, `DEFAULT_VARIANTS`, catalogs)
  live in `src/app/data.ts`, unchanged in shape from the Python constants.
