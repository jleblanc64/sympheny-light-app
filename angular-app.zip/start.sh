#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# start.sh — set up and run the Energy System Wizard (Angular) on Ubuntu.
#
# Usage:
#   ./start.sh dev              # install deps (if needed) + ng serve on :4200
#   ./start.sh build            # production build only (dist/energy-system-wizard)
#   ./start.sh serve-prod       # production build + serve it on :8080 via http-server
#
# Defaults to "dev" if no argument is given.
# Safe to re-run: skips steps that are already satisfied.
# ---------------------------------------------------------------------------
set -euo pipefail

MODE="${1:-dev}"
NODE_MAJOR="20"
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT_DEV="${PORT_DEV:-4200}"
PORT_PROD="${PORT_PROD:-8080}"

log() { echo -e "\n\033[1;32m[start.sh]\033[0m $*"; }

cd "$APP_DIR"

# ---------------------------------------------------------------------------
# 1. System packages (curl needed to add the NodeSource repo)
# ---------------------------------------------------------------------------
if ! command -v curl >/dev/null 2>&1; then
  log "Installing curl..."
  sudo apt-get update -y
  sudo apt-get install -y curl
fi

# ---------------------------------------------------------------------------
# 2. Node.js + npm (via NodeSource, gives a recent Node 20 LTS)
# ---------------------------------------------------------------------------
if ! command -v node >/dev/null 2>&1 || [[ "$(node -v | sed -E 's/^v([0-9]+).*/\1/')" -lt "$NODE_MAJOR" ]]; then
  log "Installing Node.js ${NODE_MAJOR}.x..."
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | sudo -E bash -
  sudo apt-get install -y nodejs
else
  log "Node.js already installed: $(node -v)"
fi

log "Node: $(node -v)  |  npm: $(npm -v)"

# ---------------------------------------------------------------------------
# 3. Angular CLI (local devDependency is enough, but a global CLI is handy)
# ---------------------------------------------------------------------------
if ! command -v ng >/dev/null 2>&1; then
  log "Installing Angular CLI globally..."
  sudo npm install -g @angular/cli@18
else
  log "Angular CLI already installed: $(ng version --json 2>/dev/null | grep -m1 '"Angular CLI"' || true)"
fi

# ---------------------------------------------------------------------------
# 4. Project dependencies
# ---------------------------------------------------------------------------
if [[ ! -d node_modules ]]; then
  log "Installing project dependencies (npm install)..."
  # npm ci is intentionally avoided here: with optional platform-specific
  # deps (chokidar/readdirp/esbuild), a lockfile generated on one machine
  # can make `npm ci` fail on another even right after a fresh install.
  # `npm install` resolves this reliably across environments.
  npm install --no-audit --no-fund
else
  log "node_modules already present, skipping install (delete it to force a reinstall)."
fi

# ---------------------------------------------------------------------------
# 5. Silence Angular CLI's first-run prompts (autocompletion + analytics)
#    so `ng serve`/`ng build` never block waiting for interactive input.
# ---------------------------------------------------------------------------
export NG_CLI_ANALYTICS=false
log "Disabling Angular CLI analytics and autocompletion prompt (non-interactive)..."
npx ng analytics disable --global >/dev/null 2>&1 || true
npx ng config -g cli.completion.prompted true >/dev/null 2>&1 || true

# ---------------------------------------------------------------------------
# 6. Run
# ---------------------------------------------------------------------------
case "$MODE" in
  dev)
    log "Starting dev server on http://0.0.0.0:${PORT_DEV} ..."
    exec npx ng serve --host 0.0.0.0 --port "$PORT_DEV"
    ;;

  build)
    log "Building production bundle..."
    npx ng build --configuration production
    log "Build output: ${APP_DIR}/dist/energy-system-wizard/browser"
    ;;

  serve-prod)
    log "Building production bundle..."
    npx ng build --configuration production
    if ! command -v http-server >/dev/null 2>&1; then
      log "Installing http-server globally..."
      sudo npm install -g http-server
    fi
    log "Serving production build on http://0.0.0.0:${PORT_PROD} ..."
    exec http-server "dist/energy-system-wizard/browser" -p "$PORT_PROD" -a 0.0.0.0
    ;;

  *)
    echo "Unknown mode: $MODE (expected: dev | build | serve-prod)" >&2
    exit 1
    ;;
esac
